title: springboot 进入debug模式
date: '2020-06-12 17:42:24'
updated: '2020-06-12 17:44:35'
tags: [idea, maven, springboot]
permalink: /articles/2020/06/12/1591954944189.html
---
![](https://img.hacpai.com/bing/20180218.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

这两天弄一个多模块的应用，打包后在一个文件夹，用IDEA的jrebel插件debug模式无法启动，显示一些模块读不到其他模块文件。暂时没找到合适办法，（ps:如果有小伙伴知道，欢迎告知哈～）使用maven的springboot run是可以启动的，于是想，这个能不能进入debug呢？
记录步骤如下：
# 添加插件
首先要在pom.xml中增加插件,端口号可以修改，但是需要和第二个步骤保持一致。
```
<plugin>
	<groupId>org.springframework.boot</groupId>
	<artifactId>spring-boot-maven-plugin</artifactId>
	<configuration>
		<fork>true</fork>
		<addResources>true</addResources>
		<jvmArguments>
			-Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=y,address=5005
		</jvmArguments>
	</configuration>
</plugin>
```
# 添加debug

![image.png](https://b3logfile.com/file/2020/06/image-4cfa717d.png)

![image.png](https://b3logfile.com/file/2020/06/image-825a878d.png)
按照图片顺序，给remote取个名字即可，端口号和第一步保持一致。
# 执行
先启动项目：
![image.png](https://b3logfile.com/file/2020/06/image-7eb9ef6d.png)
然后选择刚创建remote，点击debug
![image.png](https://b3logfile.com/file/2020/06/image-4ca3037c.png)
然后你就可以打断点进入调试模式啦！






