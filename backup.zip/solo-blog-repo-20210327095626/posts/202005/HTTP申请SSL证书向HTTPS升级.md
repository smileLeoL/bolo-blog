title: HTTP申请SSL证书向HTTPS升级
date: '2020-05-30 14:27:47'
updated: '2020-05-30 15:56:50'
tags: [SSL, nginx, https]
permalink: /articles/2020/05/30/1590820067462.html
---
![](https://img.hacpai.com/bing/20200107.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

前段时间，阿里云提醒SSL证书快过期了，当时项目在忙，没时间处理。趁着周末，申请下SSL证书处理下该问题，特此记录下流程。
## 1.申请证书
[SSL证书](https://baike.baidu.com/item/SSL%E8%AF%81%E4%B9%A6)是数字证书的一种，因为配置在服务器上，也称为SSL服务器证书。因为阿里云上可以直接申请证书，故直接在其上搜索申请。
申请步骤如下：
1.购买证书
选择相关产品，按需购买，本人选择是免费的一款。
![image.png](https://b3logfile.com/file/2020/05/image-a1d3dc66.png)
2.证书申请
点击证书申请，填入相关信息，等待审批就可以使用啦
![image.png](https://b3logfile.com/file/2020/05/image-dadd1515.png)
3.下载证书
下载证书放到服务器，开始进行下一步操作。
![image.png](https://b3logfile.com/file/2020/05/image-e954b1dc.png)
## 2.服务器配置
SSL证书可以在tomcat，nginx，apache等等都可以进行配置。我这里使用的是nginx。故记录的是nginx的配置过程。
一顿操作下，配置好后，发现nginx启动报错，原来，需要nginx开启ssl模块。😕 
![1.png](https://b3logfile.com/file/2020/05/1-a68eb9ca.png)
操作步骤：
**进入之前的nginx目录**
`cd /home/nginx-1.16.0  `
**配置configure**
`./configure --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_ssl_module`
**make**
`make`
*不能执行make install 会覆盖安装～*
**停止nginx，并替换之前的nginx**
`/usr/local/nginx/sbin/nginx -s stop`
`mv /usr/local/nginx/sbin/nginx    /usr/local/nginx/sbin/nginx_bak`
`cp /home/nginx-1.16.0/objs/nginx  /usr/local/nginx/sbin/nginx`
**查看安装情况**
`/usr/local/nginx/sbin/nginx -V`
```
nginx version: nginx/1.16.0
built by gcc 4.4.7 20120313 (Red Hat 4.4.7-23) (GCC) 
built with OpenSSL 1.0.1e-fips 11 Feb 2013
TLS SNI support enabled
configure arguments: --prefix=/usr/local/nginx --with-http_stub_status_module --with-http_ssl_module
```

##  3.配置nginx
 配置/usr/local/nginx/conf/nginx.conf文件  
 配置信息如下：

```
   upstream tomcatServer{
        server localhost:8080;
    }

    server {
	#http跳转到https
        listen 80 ;
        server_name www.lhlstudy.com;
        rewrite ^/(.*)$ https://www.lhlstudy.com:443$1 permanent;

     }
    server {
	#可以配置为http与https 同时存在的情况，这里配置为http强制跳转至https
        #listen 80;
        listen 443 ssl;
        server_name  www.lhlstudy.com ;

        ssl_certificate      cert/study.pem;
        ssl_certificate_key  cert/study.key;

        ssl_session_timeout 5m;
	#使用此加密套件。
        ssl_ciphers ECDHE-RSA-AES128-GCM-SHA256:ECDHE:ECDH:AES:HIGH:!NULL:!aNULL:!MD5:!ADH:!RC4;  
	#使用该协议进行配置。
        ssl_protocols TLSv1 TLSv1.1 TLSv1.2;   
        ssl_prefer_server_ciphers on;

        location / {

            proxy_redirect off;
	    #可以配置至页面静态地址，由于这里是tomcat启动，配置tomcat访问代理
            proxy_pass http://tomcatServer;
           # proxy_set_header Host $host;
            proxy_set_header Host $host:$server_port;
            proxy_set_header X-Real-IP $remote_addr;
            proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        }
       
        error_page   500 502 503 504  /50x.html;
        location = /50x.html {
            root   html;
        }
    }
```
检测配置文件是否正确
`/usr/local/nginx/sbin/nginx -t`
重启nginx
`/usr/local/nginx/sbin/nginx -s reload`
##  4.打开页面检测
 打开主页发现页面格式错乱，通过控制台发现页面资源文件还是指向http，才想起solo的博客需要在latke.properties配置文件中修改serverScheme=https。设置后，重启服务。解决问题！

	
	

