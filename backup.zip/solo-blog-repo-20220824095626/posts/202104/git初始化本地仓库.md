title: git 初始化本地仓库
date: '2021-04-29 17:38:42'
updated: '2021-04-29 17:39:29'
tags: [git]
permalink: /articles/2021/04/29/1619689122036.html
---
# git 初始化本地仓库

### 1.在码云创建仓库，并copy对应仓库名。

[https://gitee.com/tryANDtry/demo.git](https://gitee.com/tryANDtry/demo.git)

### 2.在本地创建对应目录，并执行初始化

`cd /Users/yourself/workspace/own/`

`touch  demo`

初始化本地仓库

`git init`

将本地仓库添加到本地

`git remote add origin https://gitee.com/tryANDtry/demo.git`

查看远程仓库

`git remote -v`

### 3.向远处仓库提交文件

添加到版本管理

`git add .`

提交到本地版本库

`git commit -m '你要提交的说明'`

提交到远程仓库

`git push origin master`

### 4.常见问题

1.push失败，提示：fatal: 拒绝合并无关的历史
解决办法：**`git pull origin master --allow-unrelated-histories`**

**2.仓库名称修改**

**方式一：先删除后增加**

****`git remote rm origin`****

******`git remote add origin newAddress`******

******方式二：直接修改******

********`git remote set-url origin newAddress`********

### 5.常见命令

******1.`git fetch origin` 获取远程更新******

******2.`git remote origin/master` 把更新的内容合并到本地分支******

