title: docker镜像操作
date: '2019-08-23 18:02:23'
updated: '2019-08-23 18:02:23'
tags: [docker, images, 镜像]
permalink: /articles/2019/08/23/1566554543069.html
---
![](https://img.hacpai.com/bing/20190215.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

1.拉取镜像

docker pull ubuntu:18.04

  

2.存储镜像

docker save -o /tools/ubuntu_18.04 tar ubuntu:18.04

  

3.载入镜像

docker load < ubuntu_18.04.tar.gz

docker load -i ubuntu_18.04.tar.gz

  

4.删除镜像 

docker rmi ubuntu:18.04 / docker rmi 镜像id

docker rmi -f ubuntu:18.04 强制删除镜像，不管是否包含容器，不推荐

docker image rm  

docker rm 容器id 删除镜像里容器

  

  

5.使用镜像运行

docker run -it ubuntu:18.04 bash

  

6.查看运行的容器

docker ps 

docker ps -a 查看本地所有存在的容器

  

7.查看本地镜像

docker images  /docker image ls

  

8.查看镜像历史

docker history ubuntu:18.04

  

9.查看镜像详细信息

docker  inspect ubuntu:18.04

  

10.增加镜像标签

docker tag ubuntu:latest myubuntu:latest

  
11 搜寻镜像

docker search --filter=stars=4 tensorflow 

 -f, --filter  filter: 过滤输出内容;

 - -format string: 格式化输出内容;

 --limit int:限制输出结果个数， 默认为 25 个;

 --no-trunc: 不截断输出结果。

  

12 清理镜像

docker image prune 

 -a, -all: 删除所有无用镜像， 不光是临时镜像; 

 -filter filter: 只清理符合给定过滤器的镜像; 

 -f, -force: 强制删除镜像， 而不进行提示确认。

  

13.创建镜像

i)基于已有镜像的创建

-a, --autor="": 作者信息;

-c, - -change=[] : 提交的时候执行 Dockerfile指令， 包括 CMDIENTRYPOINT 但 NV|EXPOSE|LABEL|ONBUILD|USER|VOLUME|WORKDIR等;

 -m, - -message=“”: 提交消息;

 -p, —pause=true: 提交时暂停容器运行。

docker  commit -m "Add a new file" -a "Docker NewBee" e6d609c63b4d test:0.2
![123.png](https://img.hacpai.com/file/2019/08/123-d319aaf5.png)


ii)基于本地模版创建

docker [image] i mport [OPTIONS] filelURLl -[REPOSITORY[:TAG] ]

Eg:

cat ubuntu-18.04-x86_64-minimal.tar.gz I docker import - ubuntu:lB.04

  

iii)基于dockerfile创建

dockerfile是文本文件

  

14.上传镜像

docker tag test:latest user/test:latest

docker push user/test:latest

  

15.获取帮助

docker image help

  

16.查看磁盘占用
docker system df
